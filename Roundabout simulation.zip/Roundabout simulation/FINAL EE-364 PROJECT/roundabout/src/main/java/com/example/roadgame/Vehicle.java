package com.example.roadgame;

import javafx.scene.image.Image;

public abstract class Vehicle implements Movable {
    protected int vehicleId;
    protected String vehicleType;
    protected int speed;
    protected Lane currentLane;
    protected double x, y;
    protected Image image;
    protected String direction;
    protected String exitDirection;
    protected boolean inRoundabout = false;
    protected boolean hasExited = false;
    protected double angle = 0;
    protected double entryAngle = 0;

    // Constants for roundabout
    protected static final int ROUNDABOUT_CENTER_X = 400;
    protected static final int ROUNDABOUT_CENTER_Y = 300;
    protected static final double roundaboutRadius = 100;

    public Vehicle(int vehicleId, String vehicleType, int speed, double x, double y,
                   Image image, String direction, String exitDirection) {
        this.vehicleId = vehicleId;
        this.vehicleType = vehicleType;
        this.speed = speed;
        this.x = x;
        this.y = y;
        this.image = image;
        this.direction = direction;
        this.exitDirection = exitDirection;
    }

    @Override
    public void move() {
        if (inRoundabout) {
            // Counter-clockwise movement in roundabout
            angle = (angle + speed / 30.0) % 360;
            x = ROUNDABOUT_CENTER_X + roundaboutRadius * Math.cos(Math.toRadians(angle));
            y = ROUNDABOUT_CENTER_Y + roundaboutRadius * Math.sin(Math.toRadians(angle));
        } else {
            // Regular straight-line movement
            switch (direction) {
                case "north":
                    y -= speed / 30.0;
                    break;
                case "east":
                    x += speed / 30.0;
                    break;
                case "south":
                    y += speed / 30.0;
                    break;
                case "west":
                    x -= speed / 30.0;
                    break;
            }
        }
    }

    @Override
    public void stop() {
        // Implementation for stopping the vehicle
        speed = 0;
    }

    public void enterRoundabout(double entryAngle) {
        // Prevent vehicles from entering from the outgoing line
        if (this.exitDirection.equals(this.direction)) {
            return; // Prevent entry from outgoing lane
        }

        inRoundabout = true;
        this.direction = "roundabout";
        this.entryAngle = entryAngle;
        this.angle = entryAngle;

        // Position exactly on the roundabout
        x = ROUNDABOUT_CENTER_X + roundaboutRadius * Math.cos(Math.toRadians(angle));
        y = ROUNDABOUT_CENTER_Y + roundaboutRadius * Math.sin(Math.toRadians(angle));
    }



    public void setCurrentLane(Lane lane) {
        this.currentLane = lane;
    }



    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }



    public String getDirection() {
        return direction;
    }

    public boolean isInRoundabout() {
        return inRoundabout;
    }

    public boolean hasExited() {
        return hasExited;
    }
}
