package com.example.roadgame;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import java.net.URL;


public class SimulationLauncher extends Application {


    @Override
    public void start(Stage primaryStage) {
        // Button
        Button phase1Btn = new Button("Start Phase 1");
        Button phase2Btn = new Button("Start Phase 2");
        Button analysisBtn = new Button("Show Analysis");

        // Button styles
        String buttonStyle = "-fx-background-color: #4d7080; -fx-text-fill: white; -fx-font-size: 18px; -fx-font-weight: bold;";
        phase1Btn.setStyle(buttonStyle);
        phase2Btn.setStyle(buttonStyle);
        analysisBtn.setStyle(buttonStyle);

        // Button sizes
        phase1Btn.setPrefSize(200, 60);
        phase2Btn.setPrefSize(200, 60);
        analysisBtn.setPrefSize(200, 60);

        // Button actions
        phase1Btn.setOnAction(e -> {
            try {
                MotorcycleSimulation.launchPhase();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        phase2Btn.setOnAction(e -> {
            try {
                Phase2Simulation.launchPhase();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        analysisBtn.setOnAction(e -> showCollisionBarChart());

        // Layout
        VBox layout = new VBox(30, phase1Btn, phase2Btn, analysisBtn);
        layout.setAlignment(Pos.CENTER);
        layout.setPrefSize(800, 650);

        // Set background image using method
        Image backgroundImage = getBackgroundImage();
        BackgroundSize backgroundSize = new BackgroundSize(1.0, 1.0, true, true, false, false);
        BackgroundImage bgImage = new BackgroundImage(backgroundImage,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                backgroundSize);
        layout.setBackground(new Background(bgImage));

        // Scene setup
        Scene scene = new Scene(layout);
        primaryStage.setTitle("Simulation Launcher");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }


    private Image getBackgroundImage() {
        String backgroundPath = "/images/roundabout1.png";
        URL imageUrl = getClass().getResource(backgroundPath);
        if (imageUrl == null) {
            System.err.println("Background image not found: " + backgroundPath);
            return null;
        }
        String imagePath = imageUrl.toExternalForm();
        return new Image(imagePath);
    }

    // Show bar chart for analysis
    private void showCollisionBarChart() {
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Phase");

        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Total Collisions");

        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Collision Analysis");

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Collisions");

        // Get collision totals from both simulations
        int phase1Collisions = MotorcycleSimulation.getTotalCollisions();
        int phase2Collisions = Phase2Simulation.getTotalCollisions();

        series.getData().add(new XYChart.Data<>("Phase 1", phase1Collisions));
        series.getData().add(new XYChart.Data<>("Phase 2", phase2Collisions));

        barChart.getData().add(series);

        Stage chartStage = new Stage();
        chartStage.setTitle("Collision Bar Chart");
        chartStage.setScene(new Scene(new StackPane(barChart), 800, 650));
        chartStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
