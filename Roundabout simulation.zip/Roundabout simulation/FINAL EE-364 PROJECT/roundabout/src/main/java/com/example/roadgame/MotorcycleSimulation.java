package com.example.roadgame;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.layout.VBox;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import javafx.geometry.Insets;
import javafx.util.Duration;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class MotorcycleSimulation extends Application {
    private static final int WIDTH = 800;
    private static final int HEIGHT = 650;
    private List<Vehicle> vehicles = new ArrayList<>();
    private Random random = new Random();
    private long startTime;
    private boolean timerRunning = false;
    private long elapsedTime = 0;
    private static final int ROUNDABOUT_CENTER_X = 400;
    private static final int ROUNDABOUT_CENTER_Y = 300;
    private static final int ROUNDABOUT_INNER_RADIUS = 100;
    private static final int LANE_WIDTH = 40;
    private static final int[] ROUNDABOUT_LANE_RADII = {
            ROUNDABOUT_INNER_RADIUS + LANE_WIDTH / 2,
            ROUNDABOUT_INNER_RADIUS + LANE_WIDTH + LANE_WIDTH / 2,
            ROUNDABOUT_INNER_RADIUS + 2 * LANE_WIDTH + LANE_WIDTH / 2
    };
    private static final double[] EXIT_RADII = {
            ROUNDABOUT_LANE_RADII[0] + 1,  // lane 0 (inner lane)
            ROUNDABOUT_LANE_RADII[1] + 1,  // lane 1 (middle lane)
            ROUNDABOUT_LANE_RADII[2] + 1   // lane 2 (outer lane)
    };
    private static final int ROAD_WIDTH = 190;
    private static final int ROAD_LANE_WIDTH = 30;
    private long lastVehicleTime = 0;
    private static final long VEHICLE_SPAWN_INTERVAL = 500_000_000;
    private boolean collisionDetectionEnabled = true;
    private List<Collision> collisions = new ArrayList<>();
    public static int totalCollisions = 0;
    private static double speedMultiplier = 1.0;
    private GraphicsContext statsGc;
    private double accidentRate = 0.0;
    private int totalVehiclesSpawned = 0;

    public static List<Integer> phase1CollisionsOverTime = new ArrayList<>();
    private boolean isPhaseOne = true;
    boolean isMotorcycle;



    @Override
    public void start(Stage primaryStage) {
        Canvas canvas = new Canvas(WIDTH, HEIGHT);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), e -> updateTimer()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
        primaryStage.setOnCloseRequest(event -> {
            phase1CollisionsOverTime.clear(); // Stop tracking when closed
        });


        phase1CollisionsOverTime.clear(); //  Clear old data




        Button addCarButton = new Button("Add Car");
        addCarButton.setOnAction(e -> {
            addVehicle(false);  // false = not a motorcycle
            draw(gc);


        });

        Button addMotorcycleButton = new Button("Add Motorcycle");
        addMotorcycleButton.setOnAction(e -> {
            addVehicle(true);  // true = motorcycle
            draw(gc);
        });
        Button clearButton = new Button("Clear Stats");
        Canvas statsCanvas = new Canvas(300, 120);
        statsGc = statsCanvas.getGraphicsContext2D();
        updateStatsCanvas(); // Initial drawing
        statsCanvas.setTranslateX(WIDTH / 2 - 100);
        statsCanvas.setTranslateY(-HEIGHT / 2 + 60);

        Slider speedSlider = new Slider(0, 5.0, 1.0);


        speedSlider.setShowTickLabels(true);
        speedSlider.setShowTickMarks(true);
        speedSlider.setMajorTickUnit(1);
        speedSlider.setMinorTickCount(0);
        speedSlider.setSnapToTicks(true);



        speedSlider.setPrefWidth(200);
        speedSlider.setMinWidth(15);
        speedSlider.setMaxWidth(150);

        speedSlider.setLabelFormatter(new StringConverter<Double>() {
            @Override
            public String toString(Double n) {
                return "x" + n.intValue();
            }

            @Override
            public Double fromString(String s) {
                return Double.valueOf(s.replace("x", ""));
            }
        });

        speedSlider.valueProperty().addListener((obs, oldVal, newVal) -> speedMultiplier = newVal.doubleValue());

        createInitialTraffic();

        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (now - lastVehicleTime > VEHICLE_SPAWN_INTERVAL) {
                    addRandomVehicle();
                    lastVehicleTime = now;
                }
                update();
                draw(gc);
                updateStatsCanvas();
            }
        };
        timer.start();

        VBox buttonBox = new VBox(10, addCarButton, addMotorcycleButton, clearButton, speedSlider);


        VBox controls = new VBox(10, addCarButton, addMotorcycleButton, clearButton);
        controls.setPadding(new Insets(10));
        // controls.setTranslateX(150); // positive values move right, negative move left


        StackPane root = new StackPane();
        root.getChildren().add(canvas);       // Background canvas
        root.getChildren().add(controls);     // Overlay buttons
        root.getChildren().add(statsCanvas);  // Overlay stats
        root.getChildren().add(speedSlider);
        speedSlider.setTranslateX(-WIDTH / 2 + 80);  // Shift close to left
        speedSlider.setTranslateY(HEIGHT / 2 - 40);  // Move to bottom

        primaryStage.setScene(new Scene(root, WIDTH, HEIGHT));
        primaryStage.setTitle("Roundabout Traffic Simulation");
        primaryStage.setResizable(false);
        primaryStage.show();


        clearButton.setOnAction(e -> clearStatsCanvas());
    }


    // Create initial traffic with predetermined paths (only motorcycles)
    private void createInitialTraffic() {
        // Left to right traffic (West to East) - Use adjusted positions for lanes
        for (int i = 0; i < 2; i++) {
            // Calculate proper lane position - avoid white lines
            double laneOffset = getProperLaneOffset("east", i);
            Vehicle bike = new Vehicle(
                    -50 - i * 70,
                    ROUNDABOUT_CENTER_Y + laneOffset,
                    0.5 + random.nextDouble(),
                    getRandomVehicleImage(true), // True for motorcycle
                    "east",
                    "east", // Exit direction
                    i // Lane
            );
            vehicles.add(bike);
        }

        // Bottom to top traffic (South to North) - adjusted positions
        for (int i = 0; i < 2; i++) {
            double laneOffset = getProperLaneOffset("north", i);
            vehicles.add(new Vehicle(
                    ROUNDABOUT_CENTER_X + laneOffset,
                    HEIGHT + 50 + i * 70,
                    0.5 + random.nextDouble() * 0.8,
                    getRandomVehicleImage(true), // True for motorcycle
                    "north",
                    "north", // Exit direction
                    i % 3 // Alternating lanes
            ));
        }

        // Right to left traffic (East to West) - adjusted positions
        for (int i = 0; i < 2; i++) {
            double laneOffset = getProperLaneOffset("west", i);
            vehicles.add(new Vehicle(
                    WIDTH + 50 + i * 80,
                    ROUNDABOUT_CENTER_Y + laneOffset,
                    0.5 + random.nextDouble() * 0.7,
                    getRandomVehicleImage(true), // Only motorcycles now
                    "west",
                    "west", // Exit direction
                    i % 3 // Alternating lanes
            ));
        }

        // Top to bottom traffic (North to South) - adjusted positions
        for (int i = 0; i < 2; i++) {
            double laneOffset = getProperLaneOffset("south", i);
            vehicles.add(new Vehicle(
                    ROUNDABOUT_CENTER_X + laneOffset,
                    -50 - i * 70,
                    0.5 + random.nextDouble() * 0.8,
                    getRandomVehicleImage(true), // All motorcycles now
                    "south",
                    "south", // Exit direction
                    i % 3 // Alternating lanes
            ));
        }

        // Add some vehicles that will take turns (only motorcycles)
        // Left to bottom
        vehicles.add(new Vehicle(
                -100,
                ROUNDABOUT_CENTER_Y + getProperLaneOffset("east", 1),
                0.5 + random.nextDouble() * 0.7,
                getRandomVehicleImage(true),
                "east",
                "south", // Turn to go south
                1 // Middle lane
        ));

        // Bottom to right
        vehicles.add(new Vehicle(
                ROUNDABOUT_CENTER_X + getProperLaneOffset("north", 2),
                HEIGHT + 70,
                0.5 + random.nextDouble() * 0.6,
                getRandomVehicleImage(true), // Only motorcycles now
                "north",
                "east", // Turn to go east
                2 // Outer lane
        ));

        // Top to left
        vehicles.add(new Vehicle(
                ROUNDABOUT_CENTER_X + getProperLaneOffset("south", 0),
                -80,
                0.5 + random.nextDouble() * 0.5,
                getRandomVehicleImage(true),
                "south",
                "west", // Turn to go west
                0 // Inner lane
        ));
    }



    // Helper method to get proper lane offset to avoid white lines
    private static double getProperLaneOffset(String direction, int lane) {
        double centerOffset = 0;

        // Each lane is ROAD_LANE_WIDTH wide
        switch (direction) {
            case "north": // Incoming from south
                // Only use right side of road (positive X offset) - INCOMING LANES
                centerOffset = (lane + 0.5) * ROAD_LANE_WIDTH;
                break;
            case "south": // Incoming from north
                // Only use left side of road (negative X offset) - INCOMING LANES
                centerOffset = -(lane + 0.5) * ROAD_LANE_WIDTH;
                break;
            case "east": // Incoming from west
                // Only use bottom side of road (positive Y offset) - INCOMING LANES
                centerOffset = (lane + 0.5) * ROAD_LANE_WIDTH;
                break;
            case "west": // Incoming from east
                // Only use top side of road (negative Y offset) - INCOMING LANES
                centerOffset = -(lane + 0.5) * ROAD_LANE_WIDTH;
                break;
        }

        return centerOffset;
    }

    // Add a new vehicle with random properties and path
    private void addRandomVehicle() {
        String[] entryDirections = {"north", "east", "south", "west"};
        String entryDirection = entryDirections[random.nextInt(entryDirections.length)];

        String exitDirection;
        if (random.nextDouble() < 0.6) {
            List<String> otherDirs = new ArrayList<>();
            for (String dir : entryDirections) {
                if (!dir.equals(entryDirection)) {
                    otherDirs.add(dir);
                }
            }
            exitDirection = otherDirs.get(random.nextInt(otherDirs.size()));
        } else {
            exitDirection = entryDirection;
        }

        int lane = random.nextInt(3);
        double laneOffset = getProperLaneOffset(entryDirection, lane);
        double speed = 0.20 + random.nextDouble();

        boolean isMotorcycle = random.nextBoolean();
        Vehicle v;
        double x = 0, y = 0;

        switch (entryDirection) {
            case "north":
                x = ROUNDABOUT_CENTER_X + laneOffset;
                y = HEIGHT + 50 + random.nextInt(100);
                break;
            case "east":
                x = -50 - random.nextInt(100);
                y = ROUNDABOUT_CENTER_Y + laneOffset;
                break;
            case "south":
                x = ROUNDABOUT_CENTER_X + laneOffset;
                y = -50 - random.nextInt(100);
                break;
            case "west":
                x = WIDTH + 50 + random.nextInt(100);
                y = ROUNDABOUT_CENTER_Y + laneOffset;
                break;
        }


        if (isMotorcycle && random.nextDouble() < 1) {
            v = new AgileMotorcycle(x, y, speed, getRandomVehicleImage(true), entryDirection, exitDirection, lane);
        } else {
            v = new Vehicle(x, y, speed, getRandomVehicleImage(isMotorcycle), entryDirection, exitDirection, lane);
        }
        vehicles.add(v);

        totalVehiclesSpawned++;

        if (vehicles.size() > 30) {
            vehicles.removeIf(vehicle ->
                    vehicle.x < -100 || vehicle.x > WIDTH + 100 ||
                            vehicle.y < -100 || vehicle.y > HEIGHT + 100
            );
        }
    }

    private void addVehicle(boolean isMotorcycle) {
        String[] directions = {"north", "east", "south", "west"};
        String entryDirection = directions[random.nextInt(directions.length)];

        String exitDirection;
        if (random.nextDouble() < 0.6) {
            List<String> otherDirs = new ArrayList<>();
            for (String dir : directions) {
                if (!dir.equals(entryDirection)) {
                    otherDirs.add(dir);
                }
            }
            exitDirection = otherDirs.get(random.nextInt(otherDirs.size()));
        } else {
            exitDirection = entryDirection;
        }

        int lane = random.nextInt(3);
        double laneOffset = getProperLaneOffset(entryDirection, lane);
        double speed = 0.35 + random.nextDouble();

        Vehicle v;
        double x = 0, y = 0;
        switch (entryDirection) {
            case "north":
                x = ROUNDABOUT_CENTER_X + laneOffset;
                y = HEIGHT + 50;
                break;
            case "east":
                x = -50;
                y = ROUNDABOUT_CENTER_Y + laneOffset;
                break;
            case "south":
                x = ROUNDABOUT_CENTER_X + laneOffset;
                y = -50;
                break;
            case "west":
                x = WIDTH + 50;
                y = ROUNDABOUT_CENTER_Y + laneOffset;
                break;
        }

        if (isMotorcycle && random.nextDouble() < 0.9) {
            v = new AgileMotorcycle(x, y, speed, getRandomVehicleImage(true), entryDirection, exitDirection, lane);
        } else {
            v = new Vehicle(x, y, speed, getRandomVehicleImage(isMotorcycle), entryDirection, exitDirection, lane);
        }


        vehicles.add(v);
        totalVehiclesSpawned++;
    }

    private void update() {
        // Clear previous collisions
        collisions.clear();

        // Update each vehicle
        for (Vehicle v : vehicles) {
            // Skip crashed vehicles
            if (v.isCrashed()) continue;

            v.move();

            // Check if vehicle should enter the roundabout
            if (!v.inRoundabout && !v.hasExited) {
                double distToCenter = Math.sqrt(
                        Math.pow(v.x - ROUNDABOUT_CENTER_X, 2) +
                                Math.pow(v.y - ROUNDABOUT_CENTER_Y, 2)
                );

                int targetRadius = ROUNDABOUT_LANE_RADII[v.lane];
                double entryDistance = 20;

                if (Math.abs(distToCenter - targetRadius) < entryDistance) {
                    switch (v.direction) {
                        case "east":
                            if (v.x >= ROUNDABOUT_CENTER_X - targetRadius - entryDistance) {
                                v.enterRoundabout(180);
                            }
                            break;
                        case "south":
                            if (v.y >= ROUNDABOUT_CENTER_Y - targetRadius - entryDistance) {
                                v.enterRoundabout(270);
                            }
                            break;
                        case "west":
                            if (v.x <= ROUNDABOUT_CENTER_X + targetRadius + entryDistance) {
                                v.enterRoundabout(0);
                            }
                            break;
                        case "north":
                            if (v.y <= ROUNDABOUT_CENTER_Y + targetRadius + entryDistance) {
                                v.enterRoundabout(90);
                            }
                            break;
                    }
                }
            }

            // Determine exit condition - exit at the predetermined exit
            if (v.inRoundabout && !v.hasExited) {
                double exitAngle = 0;
                switch (v.exitDirection) {
                    case "east":
                        exitAngle = 0;
                        break;
                    case "south":
                        exitAngle = 90;
                        break;
                    case "west":
                        exitAngle = 180;
                        break;
                    case "north":
                        exitAngle = 270;
                        break;
                }

                double angleDiff = Math.abs((v.angle % 360) - exitAngle);
                angleDiff = Math.min(angleDiff, 360 - angleDiff);

                if (angleDiff < 10 && Math.abs(v.angle - v.entryAngle) > 60) {
                    v.exitRoundabout();
                }
            }
        }

        if (collisionDetectionEnabled) {
            detectCollisions();
        }
    }

    private void detectCollisions() {
        // Loop through each pair of vehicles to check for collisions
        for (int i = 0; i < vehicles.size(); i++) {
            Vehicle v1 = vehicles.get(i);
            for (int j = i + 1; j < vehicles.size(); j++) {
                Vehicle v2 = vehicles.get(j);

                // Skip already crashed vehicles
                if (v1.isCrashed || v2.isCrashed) {
                    continue;
                }

                // Calculate the distance between the two vehicles
                double dx = v1.x - v2.x;
                double dy = v1.y - v2.y;
                double distance = Math.sqrt(dx * dx + dy * dy);

                // Collision distance threshold (based on vehicle sizes)
                double v1Size = v1.getVehicleSize();
                double v2Size = v2.getVehicleSize();
                double collisionThreshold = (v1Size + v2Size) / 2;

                // If the distance is less than the threshold, it indicates a collision
                if (distance < collisionThreshold) {
                    Vehicle faster = (v1.speed > v2.speed) ? v1 : v2;

                    // Mark both vehicles as crashed
                    v1.isCrashed = true;
                    v2.isCrashed = true;

                    // Stop both vehicles
                    v1.speed = 0;
                    v2.speed = 0;

                    // Optionally, remove them from the vehicles list
                    vehicles.remove(v1);  // Remove the first vehicle
                    vehicles.remove(v2);  // Remove the second vehicle

                    // Add to the collisions list for visual display
                    collisions.add(new Collision(v1, v2));

                    // Increase the total collision count
                    totalCollisions++;

                    // After removing vehicles, exit the loop as the list has changed
                    break;
                }
            }
        }
    }
    // Collision class to track collisions between vehicles
    static class Collision {
        Vehicle v1;
        Vehicle v2;

        public Collision(Vehicle v1, Vehicle v2) {
            this.v1 = v1;
            this.v2 = v2;
        }
    }
    private static final double[][] EXIT_ANGLES = {
            {280, 5, 95, 190},   // lane 0 (inner lane) // done
            {637, 17, 100, 190},   // lane 1 (middle lane)
            {650, 15, 110, 200}  // lane 2 (outer lane)
    };

    // Class representing each vehicle
    static class Vehicle {
        double x, y, speed;
        Image image;
        String direction;
        String exitDirection;
        boolean inRoundabout = false;        boolean hasExited = false;
        double angle = 0;
        double entryAngle = 0;
        int lane;
        double vehicleWidth = 30;
        double vehicleHeight = 15;

        boolean isCrashed = false; //  ADD THIS

        public boolean isCrashed() { // ADD THIS METHOD
            return isCrashed;
        }

        // Alternative approach for Vehicle constructor (preferred):
        public Vehicle(double x, double y, double speed, Image image, String direction, String exitDirection, int lane) {
            this.x = x;
            this.y = y;
            this.speed = speed;
            this.image = image;
            this.direction = direction;
            this.exitDirection = exitDirection;
            this.lane = lane;

            // Determine if it's a motorcycle by passing a boolean flag when creating vehicles
            boolean isMotorcycle = image.toString().contains("motorcycle");

            if (isMotorcycle) {
                this.vehicleWidth = 5;  // Motorcycles are smaller
                this.vehicleHeight = 5;
            } else {
                this.vehicleWidth = 20;  // Cars are larger
                this.vehicleHeight = 20;
            }
        }

        // Move the vehicle depending on its direction
        public void move() {
            double actualSpeed = speed * MotorcycleSimulation.speedMultiplier;
            if (inRoundabout) {
                angle = (angle - actualSpeed) % 360;
                double radius = ROUNDABOUT_LANE_RADII[lane];
                x = ROUNDABOUT_CENTER_X + radius * Math.cos(Math.toRadians(angle));
                y = ROUNDABOUT_CENTER_Y + radius * Math.sin(Math.toRadians(angle));
            } else {
                switch (direction) {
                    case "north": y -= actualSpeed; break;
                    case "east":  x += actualSpeed; break;
                    case "south": y += actualSpeed; break;
                    case "west":  x -= actualSpeed; break;
                }
                if (direction.equals("north") || direction.equals("south")) {
                    double targetX = ROUNDABOUT_CENTER_X + getProperLaneOffset(direction, lane);
                    if (Math.abs(x - targetX) > 0.5) {
                        x += (targetX - x) * 0.1;
                    }
                } else if (direction.equals("east") || direction.equals("west")) {
                    double targetY = ROUNDABOUT_CENTER_Y + getProperLaneOffset(direction, lane);
                    if (Math.abs(y - targetY) > 0.5) {
                        y += (targetY - y) * 0.1;

                    }
                }
            }
        }



        // Enter the roundabout at a specific angle
        public void enterRoundabout(double entryAngle) {
            inRoundabout = true;
            this.direction = "roundabout";
            this.entryAngle = entryAngle;
            this.angle = entryAngle;

            // Position exactly on the roundabout at the appropriate lane radius
            double radius = ROUNDABOUT_LANE_RADII[lane];
            x = ROUNDABOUT_CENTER_X + radius * Math.cos(Math.toRadians(angle));
            y = ROUNDABOUT_CENTER_Y + radius * Math.sin(Math.toRadians(angle));
        }


        // Exit the roundabout in the predetermined exit direction
        private void exitRoundabout() {
            int directionIndex = 0;
            switch (exitDirection) {
                case "north": directionIndex = 0; break;
                case "east":  directionIndex = 1; break;
                case "south": directionIndex = 2; break;
                case "west":  directionIndex = 3; break;
            }

            double exitAngle = MotorcycleSimulation.EXIT_ANGLES[lane][directionIndex];
            double exitRadius = EXIT_RADII[lane];

            x = ROUNDABOUT_CENTER_X + exitRadius * Math.cos(Math.toRadians(exitAngle));
            y = ROUNDABOUT_CENTER_Y + exitRadius * Math.sin(Math.toRadians(exitAngle));

            hasExited = true;
            inRoundabout = false;
            direction = exitDirection;
        }

        // Get the rotation angle in degrees for drawing
        public double getRotationAngle() {
            if (inRoundabout) {

                return (angle + 90) % 360;
            } else {
                switch (direction) {
                    case "north":
                        return (270 + 180) % 360;
                    case "east":
                        return (0 + 180) % 360;
                    case "south":
                        return (90 + 180) % 360;
                    case "west":
                        return (180 + 180) % 360;
                    default:
                        return 0;
                }
            }
        }

        // Get the vehicle width for drawing
        public double getVehicleWidth() {
            return vehicleWidth;
        }

        // Get the vehicle height for drawing
        public double getVehicleHeight() {
            return vehicleHeight;
        }

        // Get the vehicle size for collision detection
        public double getVehicleSize() {
            return Math.max(vehicleWidth, vehicleHeight);
        }
    }

    static class AgileMotorcycle extends Vehicle {
        private int switchCooldown = 0; // prevent too frequent lane switching

        public AgileMotorcycle(double x, double y, double speed, Image image, String direction, String exitDirection, int lane) {
            super(x, y, speed * 2, image, direction, exitDirection, lane); // Multiply speed
            this.vehicleWidth = 20;
            this.vehicleHeight = 20;
        }

        @Override
        public void move() {
            super.move();

            // Only switch lanes while in roundabout and not too frequently
            if (inRoundabout && switchCooldown <= 0) {
                if (Math.random() < 0.52) { // 2% chance each frame
                    // Randomly choose to switch inward or outward
                    int newLane = lane + (Math.random() < 0.9 ? -1 : 1);
                    if (newLane >= 0 && newLane < ROUNDABOUT_LANE_RADII.length) {
                        lane = newLane;
                    }
                    switchCooldown = 30; // wait 60 frames before switching again
                }
            }

            if (switchCooldown > 0) {
                switchCooldown--;
            }
        }
    }

    private void draw(GraphicsContext gc) {
        gc.clearRect(0, 0, WIDTH, HEIGHT);

        // Draw background
        gc.setFill(Color.LIGHTGRAY);
        gc.fillRect(0, 0, WIDTH, HEIGHT);

        // Draw grass areas
        gc.setFill(Color.GREEN);
        // Center of roundabout
        gc.fillOval(
                ROUNDABOUT_CENTER_X - ROUNDABOUT_INNER_RADIUS,
                ROUNDABOUT_CENTER_Y - ROUNDABOUT_INNER_RADIUS,
                2 * ROUNDABOUT_INNER_RADIUS,
                2 * ROUNDABOUT_INNER_RADIUS
        );

        // Draw corner grass areas
        // Northeast
        gc.fillRect(0, 0, ROUNDABOUT_CENTER_X - ROAD_WIDTH / 2, ROUNDABOUT_CENTER_Y - ROAD_WIDTH / 2);
        // Northwest
        gc.fillRect(ROUNDABOUT_CENTER_X + ROAD_WIDTH / 2, 0, WIDTH - ROUNDABOUT_CENTER_X - ROAD_WIDTH / 2, ROUNDABOUT_CENTER_Y - ROAD_WIDTH / 2);
        // Southwest
        gc.fillRect(0, ROUNDABOUT_CENTER_Y + ROAD_WIDTH / 2, ROUNDABOUT_CENTER_X - ROAD_WIDTH / 2, HEIGHT - ROUNDABOUT_CENTER_Y - ROAD_WIDTH / 2);
        // Southeast
        gc.fillRect(ROUNDABOUT_CENTER_X + ROAD_WIDTH / 2, ROUNDABOUT_CENTER_Y + ROAD_WIDTH / 2, WIDTH - ROUNDABOUT_CENTER_X - ROAD_WIDTH / 2, HEIGHT - ROUNDABOUT_CENTER_Y - ROAD_WIDTH / 2);

        // Draw roads (dark gray)
        gc.setFill(Color.DARKGRAY);
        // Horizontal road
        gc.fillRect(0, ROUNDABOUT_CENTER_Y - ROAD_WIDTH / 2, WIDTH, ROAD_WIDTH);
        // Vertical road
        gc.fillRect(ROUNDABOUT_CENTER_X - ROAD_WIDTH / 2,  0, ROAD_WIDTH, HEIGHT);

        // Draw 3-lane roundabout
        gc.setStroke(Color.DARKGRAY);
        gc.setFill(Color.DARKGRAY);

        // Draw the roundabout as a filled ring
        int outerRadius = ROUNDABOUT_INNER_RADIUS + 3 * LANE_WIDTH;
        gc.fillOval(
                ROUNDABOUT_CENTER_X - outerRadius,
                ROUNDABOUT_CENTER_Y - outerRadius,
                2 * outerRadius,
                2 * outerRadius
        );

        // Cut out the inner circle to create a ring
        gc.setFill(Color.GREEN);
        gc.fillOval(
                ROUNDABOUT_CENTER_X - ROUNDABOUT_INNER_RADIUS,
                ROUNDABOUT_CENTER_Y - ROUNDABOUT_INNER_RADIUS,
                2 * ROUNDABOUT_INNER_RADIUS,
                2 * ROUNDABOUT_INNER_RADIUS
        );

        // Draw lane dividers in the roundabout
        gc.setStroke(Color.WHITE);
        gc.setLineDashes(10, 10); // Dashed lines for lane dividers
        gc.setLineWidth(2);

        // Draw the two lane dividers (3 lanes total)
        for (int i = 1; i <= 2; i++) {
            int radius = ROUNDABOUT_INNER_RADIUS + i * LANE_WIDTH;
            gc.strokeOval(
                    ROUNDABOUT_CENTER_X - radius,
                    ROUNDABOUT_CENTER_Y - radius,
                    2 * radius,
                    2 * radius
            );
        }
        gc.setLineDashes(null); // Reset to solid lines

        // Draw traffic flow arrows
        drawFlowArrows(gc);

        // Road markings (white dashed lines)
        gc.setStroke(Color.WHITE);
        gc.setLineWidth(2);

        // Dividers between incoming and outgoing lanes on each road
        gc.setLineWidth(3);
        gc.setLineDashes(null); // Solid line for road dividers

        // Horizontal roads divider (reflects properly between incoming and outgoing)
        gc.strokeLine(0, ROUNDABOUT_CENTER_Y, ROUNDABOUT_CENTER_X - outerRadius - 10, ROUNDABOUT_CENTER_Y);
        gc.strokeLine(ROUNDABOUT_CENTER_X + outerRadius + 10, ROUNDABOUT_CENTER_Y, WIDTH, ROUNDABOUT_CENTER_Y);

        // Vertical roads divider
        gc.strokeLine(ROUNDABOUT_CENTER_X, 0, ROUNDABOUT_CENTER_X, ROUNDABOUT_CENTER_Y - outerRadius - 10);
        gc.strokeLine(ROUNDABOUT_CENTER_X, ROUNDABOUT_CENTER_Y + outerRadius + 10, ROUNDABOUT_CENTER_X, HEIGHT);

        // Draw lane dividers on roads
        gc.setLineWidth(1);
        gc.setLineDashes(10, 10); // Dashed lines for lane dividers

        // Horizontal road lanes (North side - Westbound)
        gc.strokeLine(0, ROUNDABOUT_CENTER_Y - ROAD_WIDTH / 6, ROUNDABOUT_CENTER_X - outerRadius - 10, ROUNDABOUT_CENTER_Y - ROAD_WIDTH / 6);
        gc.strokeLine(0, ROUNDABOUT_CENTER_Y - ROAD_WIDTH / 3, ROUNDABOUT_CENTER_X - outerRadius - 10, ROUNDABOUT_CENTER_Y - ROAD_WIDTH / 3);

        // Horizontal road lanes (South side - Eastbound)
        gc.strokeLine(0, ROUNDABOUT_CENTER_Y + ROAD_WIDTH / 6, ROUNDABOUT_CENTER_X - outerRadius - 10, ROUNDABOUT_CENTER_Y + ROAD_WIDTH / 6);
        gc.strokeLine(0, ROUNDABOUT_CENTER_Y + ROAD_WIDTH / 3, ROUNDABOUT_CENTER_X - outerRadius - 10, ROUNDABOUT_CENTER_Y + ROAD_WIDTH / 3);

        // East side of horizontal road
        gc.strokeLine(ROUNDABOUT_CENTER_X + outerRadius + 10, ROUNDABOUT_CENTER_Y - ROAD_WIDTH / 6, WIDTH, ROUNDABOUT_CENTER_Y - ROAD_WIDTH / 6);
        gc.strokeLine(ROUNDABOUT_CENTER_X + outerRadius + 10, ROUNDABOUT_CENTER_Y - ROAD_WIDTH / 3, WIDTH, ROUNDABOUT_CENTER_Y - ROAD_WIDTH / 3);
        gc.strokeLine(ROUNDABOUT_CENTER_X + outerRadius + 10, ROUNDABOUT_CENTER_Y + ROAD_WIDTH / 6, WIDTH, ROUNDABOUT_CENTER_Y + ROAD_WIDTH / 6);
        gc.strokeLine(ROUNDABOUT_CENTER_X + outerRadius + 10, ROUNDABOUT_CENTER_Y + ROAD_WIDTH / 3, WIDTH, ROUNDABOUT_CENTER_Y + ROAD_WIDTH / 3);

        // Vertical road lanes (West side - Southbound)
        gc.strokeLine(ROUNDABOUT_CENTER_X - ROAD_WIDTH / 6, 0, ROUNDABOUT_CENTER_X - ROAD_WIDTH / 6, ROUNDABOUT_CENTER_Y - outerRadius - 10);
        gc.strokeLine(ROUNDABOUT_CENTER_X - ROAD_WIDTH / 3, 0, ROUNDABOUT_CENTER_X - ROAD_WIDTH / 3, ROUNDABOUT_CENTER_Y - outerRadius - 10);

        // Vertical road lanes (East side - Northbound)
        gc.strokeLine(ROUNDABOUT_CENTER_X + ROAD_WIDTH / 6, 0, ROUNDABOUT_CENTER_X + ROAD_WIDTH / 6, ROUNDABOUT_CENTER_Y - outerRadius - 10);
        gc.strokeLine(ROUNDABOUT_CENTER_X + ROAD_WIDTH / 3, 0, ROUNDABOUT_CENTER_X + ROAD_WIDTH / 3, ROUNDABOUT_CENTER_Y - outerRadius - 10);

        // South side of vertical road
        gc.strokeLine(ROUNDABOUT_CENTER_X - ROAD_WIDTH / 6, ROUNDABOUT_CENTER_Y + outerRadius + 10, ROUNDABOUT_CENTER_X - ROAD_WIDTH / 6, HEIGHT);
        gc.strokeLine(ROUNDABOUT_CENTER_X - ROAD_WIDTH / 3, ROUNDABOUT_CENTER_Y + outerRadius + 10, ROUNDABOUT_CENTER_X - ROAD_WIDTH / 3, HEIGHT);
        gc.strokeLine(ROUNDABOUT_CENTER_X + ROAD_WIDTH / 6, ROUNDABOUT_CENTER_Y + outerRadius + 10, ROUNDABOUT_CENTER_X + ROAD_WIDTH / 6, HEIGHT);
        gc.strokeLine(ROUNDABOUT_CENTER_X + ROAD_WIDTH / 3, ROUNDABOUT_CENTER_Y + outerRadius + 10, ROUNDABOUT_CENTER_X + ROAD_WIDTH / 3, HEIGHT);

        gc.setLineDashes(null); // Reset to solid lines

        // Crosswalk markings
        drawCrosswalk(gc, ROUNDABOUT_CENTER_X - outerRadius - 60, ROUNDABOUT_CENTER_Y - 20, 50, 40, true);  // West
        drawCrosswalk(gc, ROUNDABOUT_CENTER_X - 20, ROUNDABOUT_CENTER_Y - outerRadius - 60, 40, 50, false); // North
        drawCrosswalk(gc, ROUNDABOUT_CENTER_X + outerRadius + 10, ROUNDABOUT_CENTER_Y - 20, 50, 40, true);  // East
        drawCrosswalk(gc, ROUNDABOUT_CENTER_X - 20, ROUNDABOUT_CENTER_Y + outerRadius + 10, 40, 50, false); // South

        // Draw vehicles
        for (Vehicle v : vehicles) {
            drawRotatedImage(gc, v.image, v.x, v.y, v.getRotationAngle(), v.getVehicleWidth(), v.getVehicleHeight());
        }





        // Draw legend for roundabout
        gc.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        gc.fillText("ROUNDABOUT", ROUNDABOUT_CENTER_X - 60, ROUNDABOUT_CENTER_Y + 10);
        // Draw the timer
        gc.setFill(Color.BLACK);
        gc.setFont(Font.font("Arial", FontWeight.BOLD, 14));


    }

    // Draw traffic flow arrows - Adjusted positions for bottom line
    private void drawFlowArrows(GraphicsContext gc) {
        // Set arrow style
        gc.setFill(Color.YELLOW);
        gc.setStroke(Color.BLACK);
        gc.setLineWidth(1);


        for (int lane = 0; lane < 3; lane++) {
            int radius = ROUNDABOUT_LANE_RADII[lane];

            // Place arrows at 8 positions around the circle
            for (int i = 0; i < 8; i++) {
                double angle = i * 45;
                double x = ROUNDABOUT_CENTER_X + radius * Math.cos(Math.toRadians(angle));
                double y = ROUNDABOUT_CENTER_Y + radius * Math.sin(Math.toRadians(angle));

                // Arrow should be tangent to the circle
                drawArrow(gc, x, y, 20, 6, angle + 90);
            }
        }

        // Road Labels with directional information
        gc.setFont(Font.font("Arial", FontWeight.BOLD, 10));
        gc.setFill(Color.BLACK);

        // West Road
        gc.fillText("→ INCOMING →", 50, ROUNDABOUT_CENTER_Y + 50);
        gc.fillText("← OUTGOING ←", 50, ROUNDABOUT_CENTER_Y - 42.5);

        // East Road
        gc.fillText("← INCOMING ←", WIDTH - 150, ROUNDABOUT_CENTER_Y - 42.5);
        gc.fillText("→ OUTGOING →", WIDTH - 150, ROUNDABOUT_CENTER_Y + 50);

        // North Road
        gc.fillText("↓ INCOMING", ROUNDABOUT_CENTER_X - 75, 50);
        gc.fillText("↑ OUTGOING", ROUNDABOUT_CENTER_X + 10, 50);


        // South Road
        gc.fillText("↑ INCOMING", ROUNDABOUT_CENTER_X + 10, HEIGHT - 50);
        gc.fillText("↓ OUTGOING", ROUNDABOUT_CENTER_X - 75, HEIGHT - 50);

    }

    // Draw arrow method
    private void drawArrow(GraphicsContext gc, double x, double y, double length, double width, double angleDegrees) {
        gc.save();
        gc.translate(x, y);
        gc.rotate(angleDegrees);

        // Arrow body
        gc.setFill(Color.DARKGRAY);
        gc.fillRect(-length / 2, -width / 2, length, width);

        // Arrow head (→)
        double[] xPoints =  {-length / 2, -length / 2 + width, -length / 2 + width};
        double[] yPoints = {0, -width, width};
        gc.fillPolygon(xPoints, yPoints, 3);

        // Border
        gc.setStroke(Color.BLACK);
        gc.strokeRect(-length / 2, -width / 2, length, width);
        gc.strokePolygon(xPoints, yPoints, 3);

        gc.restore();
    }

    // Draw a crosswalk with parallel lines
    private void drawCrosswalk(GraphicsContext gc, double x, double y, double width, double height, boolean horizontal) {
        int stripes = 6;
        double spacing = (horizontal ? width : height) / stripes;

        for (int i = 0; i < stripes; i++) {
            if (horizontal) {
                double startX = x + i * spacing;
                gc.strokeLine(startX, y, startX, y + height);
            } else {
                double startY = y + i * spacing;
                gc.strokeLine(x, startY, x + width, startY);
            }
        }
    }

    // Get random image for either motorcycles or cars
    private Image getRandomVehicleImage(boolean isMotorcycle) {
        String[] motorcycleImages = {
                "/images/motorcycle_black.png",
                "/images/motorcycle_red.png",
                "/images/motorcycle_yellow.png"
        };
        String[] carImages = {
                "/images/car_gray.png",
                "/images/car_red.png",
                "/images/car_white.png"
        };

        String chosenImage;
        if (isMotorcycle) {
            chosenImage = motorcycleImages[random.nextInt(motorcycleImages.length)];
        } else {
            chosenImage = carImages[random.nextInt(carImages.length)];
        }

        URL imageUrl = getClass().getResource(chosenImage);
        String imagePath = imageUrl.toExternalForm();
        Image image = new Image(imagePath);
        return image;

    }



    // Method to draw the vehicle with correct rotation
    private void drawRotatedImage(GraphicsContext gc, Image image, double x, double y, double angleDegrees, double width, double height) {
        gc.save();
        gc.translate(x, y);
        gc.rotate(angleDegrees);
        gc.drawImage(image, -width / 2, -height / 2, width, height);
        gc.restore();
    }
    // Timer update method
    private void updateTimer() {
        if (!timerRunning) {
            startTime = System.nanoTime();  // Start the timer
            timerRunning = true;
        }
        elapsedTime = (System.nanoTime() - startTime) / 1_000_000_000L; // Convert to seconds
    }


    private void updateStatsCanvas() {
        statsGc.setFill(Color.WHITE);
        statsGc.fillRect(20, 0, 350, 200);
        statsGc.setStroke(Color.BLACK);
        statsGc.strokeRect(20, 0, 350, 200);
        statsGc.setFill(Color.BLACK);
        statsGc.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        statsGc.fillText("      Simulation Stats", 50, 20);
        statsGc.setFont(Font.font("Arial", 12));

        // Calculate accident rate
        int vehicleCount = vehicles.size();
        if (vehicleCount > 0) {
            accidentRate = (double) totalCollisions / totalVehiclesSpawned;
        } else {
            accidentRate = 0.0;
        }


        if (isPhaseOne) {
            phase1CollisionsOverTime.add(totalCollisions);
        }


        statsGc.fillText("      Total Vehicles: " + totalVehiclesSpawned, 10, 55);
        statsGc.fillText("      Collisions: " + totalCollisions, 10, 70);
        statsGc.fillText("      Accident Rate: " + String.format("%.2f%%", accidentRate * 100), 10, 85);

        statsGc.fillText("      Time: " + elapsedTime + "s", 10, 100);

    }

    private void clearStatsCanvas() {
        // Reset stats
        elapsedTime = 0;
        totalCollisions = 0;
        totalVehiclesSpawned = 0;  // <-- Reset total vehicle counter

        vehicles.clear();

        // Clear and redraw the stats box
        statsGc.setFill(Color.WHITE);
        statsGc.fillRect(20, 0, 350, 200);
        statsGc.setStroke(Color.BLACK);
        statsGc.strokeRect(20, 0, 350, 200);

        statsGc.setFill(Color.BLACK);
        statsGc.setFont(Font.font("Arial", FontWeight.BOLD, 12));

        timerRunning = false; // So timer restarts cleanly
    }



    public static void launchPhase() {
        try {
            new MotorcycleSimulation().start(new Stage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int getTotalCollisions() {
        return totalCollisions;
    }

}