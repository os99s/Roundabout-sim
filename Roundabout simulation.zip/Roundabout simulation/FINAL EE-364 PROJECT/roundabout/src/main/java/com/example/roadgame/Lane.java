// Lane.java
package com.example.roadgame;

import java.util.ArrayList;
import java.util.List;

public class Lane {
    private int laneId;
    private List<Vehicle> vehicles;

    public Lane(int laneId) {
        this.laneId = laneId;
        this.vehicles = new ArrayList<>();
    }

    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
        vehicle.setCurrentLane(this);
    }

    public void removeVehicle(Vehicle vehicle) {
        vehicles.remove(vehicle);
    }

    public int getLaneId() {
        return laneId;
    }

    public List<Vehicle> getVehicles() {
        return vehicles;
    }
}
