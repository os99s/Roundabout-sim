// Car.java
package com.example.roadgame;

import javafx.scene.image.Image;

public class Car extends Vehicle {
    private String carModel;

    public Car(int vehicleId, int speed, String carModel, double x, double y,
               Image image, String direction, String exitDirection) {
        super(vehicleId, "Car", speed, x, y, image, direction, exitDirection);
        this.carModel = carModel;
    }

    public void accelerate() {
        speed += 10;
    }

    public void brake() {
        speed = Math.max(0, speed - 15);
    }

    @Override
    public void move() {
        super.move();
        // Car-specific movement behavior could be added here
    }

    @Override
    public void stop() {
        super.stop();
        // Car-specific stopping behavior
    }

    public String getCarModel() {
        return carModel;
    }
}
