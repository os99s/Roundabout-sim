// Movable.java (Interface)
package com.example.roadgame;

public interface Movable {
    void move();
    void stop();
}