// Roundabout.java
package com.example.roadgame;

import java.util.ArrayList;
import java.util.List;

public class Roundabout {

    private List<Vehicle> vehicles;

    // Roundabout properties
    private static final int ROUNDABOUT_CENTER_X = 400;
    private static final int ROUNDABOUT_CENTER_Y = 300;
    private static final int ROUNDABOUT_RADIUS = 100;
    private static final int ROAD_WIDTH = 60;

    public Roundabout() {
        this.vehicles = new ArrayList<>();
    }

    public void manageTraffic() {
        // Check for vehicles approaching roundabout
        for (Vehicle vehicle : vehicles) {
            if (!vehicle.isInRoundabout() && !vehicle.hasExited()) {
                double distToCenter = Math.sqrt(
                        Math.pow(vehicle.getX() - ROUNDABOUT_CENTER_X, 2) +
                                Math.pow(vehicle.getY() - ROUNDABOUT_CENTER_Y, 2)
                );

                if (distToCenter <= ROUNDABOUT_RADIUS + ROAD_WIDTH/2 &&
                        distToCenter >= ROUNDABOUT_RADIUS - ROAD_WIDTH/2) {

                    // Calculate entry angle based on approach direction
                    switch(vehicle.getDirection()) {
                        case "east":
                            if (vehicle.getX() >= ROUNDABOUT_CENTER_X - ROUNDABOUT_RADIUS - 10) {
                                vehicle.enterRoundabout(180);
                            }
                            break;
                        case "south":
                            if (vehicle.getY() >= ROUNDABOUT_CENTER_Y - ROUNDABOUT_RADIUS - 10) {
                                vehicle.enterRoundabout(270);
                            }
                            break;
                        case "west":
                            if (vehicle.getX() <= ROUNDABOUT_CENTER_X + ROUNDABOUT_RADIUS + 10) {
                                vehicle.enterRoundabout(0);
                            }
                            break;
                        case "north":
                            if (vehicle.getY() <= ROUNDABOUT_CENTER_Y + ROUNDABOUT_RADIUS + 10) {
                                vehicle.enterRoundabout(90);
                            }
                            break;
                    }
                }
            }
        }
    }
}
