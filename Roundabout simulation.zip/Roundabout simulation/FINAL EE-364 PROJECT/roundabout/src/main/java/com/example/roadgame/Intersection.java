// Intersection.java
package com.example.roadgame;

import java.util.ArrayList;
import java.util.List;

public class Intersection {
    private List<Road> connectingRoads;
    private Roundabout roundabout;

    public Intersection(Roundabout roundabout) {
        this.connectingRoads = new ArrayList<>();
        this.roundabout = roundabout;
    }

    public void manageTraffic() {
        // Logic for traffic management at the intersection
        // Example: Check for potential collisions
        for (Road road : connectingRoads) {
            road.updateAccidentRate();
        }

        // Delegate to roundabout if present
        if (roundabout != null) {
            roundabout.manageTraffic();
        }
    }
}