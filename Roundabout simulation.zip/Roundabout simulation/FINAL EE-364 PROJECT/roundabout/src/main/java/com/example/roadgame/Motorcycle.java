// Motorcycle.java
package com.example.roadgame;

import javafx.scene.image.Image;

public class Motorcycle extends Vehicle {
    private String motorcycleModel;

    public Motorcycle(int vehicleId, int speed, String motorcycleModel, double x, double y,
                      Image image, String direction, String exitDirection) {
        super(vehicleId, "Motorcycle", speed, x, y, image, direction, exitDirection);
        this.motorcycleModel = motorcycleModel;
    }

    @Override
    public void move() {
        super.move();
        // Motorcycle-specific movement behavior could be added here
    }

    @Override
    public void stop() {
        super.stop();
        // Motorcycle-specific stopping behavior
    }
}
